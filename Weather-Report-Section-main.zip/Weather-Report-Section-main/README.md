# Weather-Report-Section
![weather-report-section-portrait-v2](https://user-images.githubusercontent.com/81244698/137245295-7c29157c-3548-4b20-a992-50853e1c6ea6.png)
