# Todos-Application
![todo-application-part-6-v1](https://user-images.githubusercontent.com/81244698/133991697-50c01bff-a21d-4b09-a2db-a828f38b127d.gif)
