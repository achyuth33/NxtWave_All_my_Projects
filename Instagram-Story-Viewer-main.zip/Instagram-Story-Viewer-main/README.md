# Instagram-Story-Viewer
![instagram-story-viewer-sm-output](https://user-images.githubusercontent.com/81244698/140070286-e0f3f71a-a866-41f9-8937-7a529b678130.gif)
