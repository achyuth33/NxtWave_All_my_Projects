# Matrix-Diagonal-Sum
Python Program
