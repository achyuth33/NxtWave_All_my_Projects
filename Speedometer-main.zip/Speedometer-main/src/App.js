import Speedometer from './components/Speedometer'

import './App.css'

const App = () => <Speedometer />

export default App
