# On - Demand Session

- Identifying the State
- Updating the styles based on State
