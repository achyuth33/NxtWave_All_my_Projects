import './App.css'

import LettersCalculator from './components/LettersCalculator'

const App = () => <LettersCalculator />

export default App
