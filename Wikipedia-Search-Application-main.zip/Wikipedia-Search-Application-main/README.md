# Wikipedia-Search-Application
![wikipedia-search-application-v1](https://user-images.githubusercontent.com/81244698/135093986-d6c1baee-cc72-4498-8b7c-58a21e28339f.gif)
