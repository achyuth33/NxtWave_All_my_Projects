import PasswordManager from './components/PasswordManager'
import './App.css'

const App = () => (
  <div>
    <PasswordManager />
  </div>
)

export default App
