# Responsive-Navbar
![landing-page-sm-output-v3](https://user-images.githubusercontent.com/81244698/137245973-bc4dd802-c765-4609-8dad-5e307103e39c.gif)
