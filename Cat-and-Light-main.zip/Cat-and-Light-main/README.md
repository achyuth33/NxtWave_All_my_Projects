# Cat & Light Project

## Observations

- Switch status changes
- Bulb goes On and Off
- Cat become Visible and Invisible
- Switch (button) background color Changes
