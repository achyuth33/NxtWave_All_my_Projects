# Class Component and State Part 2

```
https://assets.ccbp.in/frontend/react-js/cross-img.png
```
