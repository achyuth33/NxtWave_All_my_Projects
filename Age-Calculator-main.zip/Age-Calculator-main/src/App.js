import AgeCalculator from './components/AgeCalculator'

import './App.css'

const App = () => <AgeCalculator />

export default App
