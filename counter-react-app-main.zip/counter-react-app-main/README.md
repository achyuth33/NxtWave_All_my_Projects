# Class Component and State

- Class Component
  - Syntax
- Handling Events in React
  - Syntax
- State
  - setState()
