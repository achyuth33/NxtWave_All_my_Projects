import Counter from './components/Counter'

const App = () => {
  return <Counter />
}
export default App
