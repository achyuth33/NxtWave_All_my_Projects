const Welcome = () => <h1>Hello, User</h1>

export default Welcome
