# Freemium-Business-Model
![freemium-business-model-portrait](https://user-images.githubusercontent.com/81244698/140071173-6e4fddbd-7402-4445-9c30-aa19a454ec20.png)
