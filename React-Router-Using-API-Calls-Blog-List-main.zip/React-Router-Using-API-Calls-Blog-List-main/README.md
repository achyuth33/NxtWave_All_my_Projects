# Routing using react-router Part 2

- API Calls
  - Using fetch()
- Third-Party Packages
  - react-loader-spinner
