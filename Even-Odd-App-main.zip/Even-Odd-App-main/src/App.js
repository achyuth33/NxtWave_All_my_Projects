import EvenOddApp from './components/EvenOddApp'
import './App.css'

const App = () => <EvenOddApp />

export default App
