import ClickCounter from './components/ClickCounter'

import './App.css'

const App = () => <ClickCounter />

export default App
