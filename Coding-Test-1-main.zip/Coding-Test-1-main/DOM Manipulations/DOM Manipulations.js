let mainHeadingElement = document.getElementById("mainHeading");
mainHeadingElement.textContent = "Welcome to JS";
mainHeadingElement.style.color = "#b942f5";
mainHeadingElement.style.backgroundColor = "#000000";
mainHeadingElement.style.fontFamily = "Roboto";
