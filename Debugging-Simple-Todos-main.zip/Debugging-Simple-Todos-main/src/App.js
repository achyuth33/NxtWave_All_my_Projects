import SimpleTodos from './components/SimpleTodos'

import './App.css'

const App = () => <SimpleTodos />

export default App
