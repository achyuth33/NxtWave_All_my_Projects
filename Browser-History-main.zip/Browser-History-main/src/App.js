import BrowserHistory from './components/BrowserHistory'
import './App.css'

const App = () => <BrowserHistory />

export default App
